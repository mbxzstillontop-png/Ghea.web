const $=s=>document.querySelector(s);
function image(id,url){const e=$(id);if(!e)return;if(url&&!url.startsWith("URL_"))e.src=url;else e.removeAttribute("src")}
window.addEventListener("DOMContentLoaded",()=>{

  const bg = $("#gardenBg");
  if (bg && GHEA_CONFIG.background?.imageUrl && !GHEA_CONFIG.background.imageUrl.startsWith("URL_")) {
    bg.style.setProperty("--garden-image", `url("${GHEA_CONFIG.background.imageUrl}")`);
    bg.style.setProperty("--garden-blur", `${GHEA_CONFIG.background.blur ?? 0}px`);
    bg.style.setProperty("--garden-opacity", `${GHEA_CONFIG.background.overlayOpacity ?? 0.38}`);
  } else if (bg) {
    bg.style.setProperty("--garden-image", "none");
  }

  const particleLayer = $("#particles");
  if (particleLayer) {
    const count = window.innerWidth < 700 ? 24 : 42;
    for (let i = 0; i < count; i++) {
      const p = document.createElement("span");
      p.className = "particle" + (Math.random() > 0.72 ? " petal" : "");
      p.style.setProperty("--size", `${Math.random() * 4 + 2}px`);
      p.style.setProperty("--alpha", `${Math.random() * 0.45 + 0.25}`);
      p.style.setProperty("--left", `${Math.random() * 100}%`);
      p.style.setProperty("--top", `${Math.random() * 110}%`);
      p.style.setProperty("--duration", `${Math.random() * 13 + 10}s`);
      p.style.setProperty("--drift", `${(Math.random() * 180 - 90).toFixed(0)}px`);
      p.style.setProperty("--rotate", `${Math.random() * 360}deg`);
      p.style.animationDelay = `${-Math.random() * 18}s`;
      particleLayer.appendChild(p);
    }
  }

  $("#version").textContent=GHEA_CONFIG.site.version;
  $("#description").textContent=GHEA_CONFIG.site.description;
  $("#copyright").textContent=GHEA_CONFIG.developer.copyright;
  image("#navLogo",GHEA_CONFIG.branding.logo);image("#heroLogo",GHEA_CONFIG.branding.logo);
  if(GHEA_CONFIG.branding.favicon&&!GHEA_CONFIG.branding.favicon.startsWith("URL_"))$("#favicon").href=GHEA_CONFIG.branding.favicon;
  $("#downloadBtn").href=GHEA_CONFIG.download.url;
  $("#filename").textContent=GHEA_CONFIG.download.filename;
  const devUrl=GHEA_CONFIG.developer.url;
  const devBtn=$("#developerBtn"),devLink=$("#developerLink");
  if(devUrl&&!devUrl.startsWith("URL_")){
    devBtn.href=devUrl; devLink.href=devUrl;
  }else{
    devBtn.href="#"; devLink.href="#";
    devBtn.addEventListener("click",e=>e.preventDefault());
    devLink.addEventListener("click",e=>e.preventDefault());
  }
  const audio=$("#audio"),sound=$("#sound");
  if(GHEA_CONFIG.audio.enabled&&GHEA_CONFIG.audio.url&&!GHEA_CONFIG.audio.url.startsWith("URL_")){
    audio.src=GHEA_CONFIG.audio.url;audio.volume=GHEA_CONFIG.audio.volume;
    sound.onclick=async()=>{if(audio.paused){try{await audio.play();sound.textContent="◉"}catch{}}else{audio.pause();sound.textContent="○"}};
  }else sound.style.opacity=".35";
  $("#menu").onclick=()=>$("#nav").classList.toggle("open");
  document.querySelectorAll("nav a").forEach(a=>a.onclick=()=>$("#nav").classList.remove("open"));
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")}),{threshold:.12});
  document.querySelectorAll(".reveal").forEach(e=>io.observe(e));
  setTimeout(()=>$("#loader").classList.add("done"),1450);
});