const GHEA_CONFIG = {
  site: {
    name: "GHEA",
    version: "V1",
    tagline: "A refined WhatsApp bot experience.",
    description: "GHEA hadir dengan pendekatan yang clean, modern, dan fleksibel — dibuat untuk pengalaman bot yang lebih terstruktur."
  },
  branding: {
    heroLogo: "https://cdn.zass.in/EiVlcXdD0v.jpeg",
    navLogo: "https://cdn.zass.in/QT70bNOasp.jpeg",
    favicon: "https://cdn.zass.in/0fLF5APbvZ.jpeg"
  },

  background: {
    imageUrl: "https://cdn.zass.in/idvU2RPnJO.jpeg",
    overlayOpacity: 0.38,
    blur: 0.4
  },
  audio: {
    enabled: true,
    url: "https://cdn.zass.in/NsjXKKddeR.mpeg",
    volume: 0.45
  },
  download: {
    url: "",
    filename: "GHEA-V1.zip"
  },
  developer: {
    name: "AlwaysLennz",
    url: "https://wa.me/6285129673931",
    copyright: "© 2026 LENNZ Project. All Rights Reserved."
  }
};
