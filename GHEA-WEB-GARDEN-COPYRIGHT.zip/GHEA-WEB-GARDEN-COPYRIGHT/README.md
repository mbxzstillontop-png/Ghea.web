# GHEA Official Website — Garden Edition

GHEA website for GitHub Pages with a garden background, particles, GHEA branding, copyright, and developer link.

Edit `config.js`:
- `branding.heroLogo`
- `branding.navLogo`
- `branding.favicon`
- `background.imageUrl`
- `audio.url`
- `download.url`
- `developer.url`

The Developer button appears in the navigation and download section and opens the configured developer URL in a new tab.

No backend or Node.js required.
